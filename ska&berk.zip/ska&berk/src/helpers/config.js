export default {
  listenerToken: "",
  sniperToken: "",
  sniperGuild: "",
  webhooks: {
    successUrl: "", 
    errorUrl: "",
    infoUrl: "",
  },
  gif: "", 
};
