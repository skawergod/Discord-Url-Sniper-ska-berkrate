import config from "./config.js";
import axios from "axios";

const payload = {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
};

export default {
  success: async (url, serverId) => {
    const embed = {
      fields: [
        {
          name: "Alınan Url",
          value: `\`\`\`${url}\`\`\``,
        },
        {
          name: "Sunucu ID",
          value: `\`\`\`${serverId}\`\`\``,
        },
      ],
      color: 3066993,
      image: {
        url: config.gif,
      },
      footer: {
        text: "developed by berk' rate",
      },
    };

    try {
      await axios.post(config.webhooks.successUrl, {
        content: "||@everyone||",
        embeds: [embed],
      });
    } catch (error) {
      console.error("Success Webhookunu Gönderirken Hata Oluştu. Hata Kodu:", error);
    }
  },
  info: async (str) => {
    const embed = {
      description: str,
      color: 3447003,
      image: {
        url: config.gif, 
      },
      footer: {
        text: "developed by berk' rate",
      },
    };

    try {
      await axios.post(config.webhooks.infoUrl, {
        embeds: [embed],
      });
    } catch (error) {
      console.error("İnfo Webhookunu Gönderirken Hata Oluştu. Hata Kodu:", error);
    }
  },
  error: async (url,) => {
    const embed = {
      fields: [
        {
          name: "Fail Yenen Url",
          value: `\`\`\`discord.gg/${url}\`\`\``,
        },
        {
          name: "Hata Kodu",
          value: `\`\`\`Url Kaçtı/Banlandım/Kicklendim\`\`\``,
        },
      ],
      color: 15158332,
      image: {
        url: config.gif,
      },
      footer: {
        text: "developed by berk' rate",
      },
    };

    try {
      await axios.post(config.webhooks.errorUrl, {
        content: "||@everyone||",
        embeds: [embed],
      });
    } catch (error) {
      console.error("Hata Webhookunu Gönderirken Hata Oluştu. Hata Kodu:", error);
    }
  },
};
