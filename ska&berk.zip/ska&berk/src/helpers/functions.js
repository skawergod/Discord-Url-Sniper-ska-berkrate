import config from "./config.js";

export default {
  snipeVanityUrl: async (vanity_url) => {
    try {
      const send = await fetch(
        `https://discord.com/api/v10/guilds/${config.sniperGuild}/vanity-url`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: config.sniperToken,
          },
          body: JSON.stringify({ code: vanity_url }),
        }
      );

      if (!send.ok) {
        throw new Error(send.status.toString());
      }

      return true;
    } catch (error) {
      throw error;
    }
  },

};
