import chalk from "chalk";
import { createRequire } from 'module';
import WebSocket from "ws";
const require = createRequire(import.meta.url);
import webhooks from "./helpers/webhooks.js";
import functions from "./helpers/functions.js";
const cas = require('../node_modules/cas-clack/cas.js'); 
import config from "./helpers/config.js";
const guilds = {};
const info = (str) => console.log(`${chalk.hex("#ed2d8d")("")} ${chalk.hex("#fff")(str)}`);
const error = (str) => console.log(`${chalk.hex(`#f00a0d`)("")} ${chalk.hex("#fff")(str)}`);
const statusCodes = {400: "url kaçırıldı.", 429: "rate limit.", 403: "yetkisiz.", 401: "yetkisiz.",};
const ws = new WebSocket(`wss://gateway-us-east1-b.discord.gg`);

ws.on("open", () => {
  ws.on("message", async (message) => {
    const { d, op, t } = JSON.parse(message);
    if (t === "GUILD_UPDATE") {
      const getGuild = guilds[d.guild_id];

      if (typeof getGuild === "string" && getGuild !== d.vanity_url_code) {
        try {
          await functions.snipeVanityUrl(getGuild);
          delete guilds[d.guild_id];
          await webhooks.success(`discord.gg/${getGuild}`, d.guild_id);
        } catch (err) {
          delete guilds[d.guild_id];
        }
      }
    } else if (t === "GUILD_DELETE") {
      const getGuild = guilds[d.id];

      if (getGuild) {
        try {
          await functions.snipeVanityUrl(getGuild);
          delete guilds[d.id];
        } catch (err) {
          const statusCode = statusCodes[err] || err;
          await webhooks.error(getGuild, statusCode);
        }
      }
    } else if (t === "READY") {
      info(`Log Atıldı`);

      d.guilds
        .filter((e) => e.vanity_url_code)
        .forEach((guild) => (guilds[guild.id] = guild.vanity_url_code));
      
      const guildUrls = d.guilds
        .filter((e) => e.vanity_url_code)
        .map((guild) => guild.vanity_url_code);
      const numGuilds = d.guilds.filter((e) => e.vanity_url_code).length;
      await webhooks.info(`xxx ${numGuilds} xxx \n\`\`\`\n${guildUrls}\n\`\`\``);
    }

    if (op === 10) {
      ws.send(
        JSON.stringify({
          op: 2,
          d: {
            token: config.listenerToken,
            intents: 1,
            properties: {
              os: "linux",
              browser: "firefox",
              device: "firefox",
            },
          },
        })
      );

      setInterval(() => {
        ws.send(JSON.stringify({ op: 1, d: {}, s: null, t: "heartbeat" }));
      }, d.heartbeat_interval);
    } else if (op === 7) {
      return process.exit();
    }
  });

  ws.on("close", (code) => {
    if (code === 4004) {
      error(`sniper tokeni yanlış`);
    }
  });
});
